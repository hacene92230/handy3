<?php
header('location: /');
