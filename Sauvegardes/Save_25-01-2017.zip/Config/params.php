<?php

    $config['db_site']['hostname']         = 'localhost';
    $config['db_site']['database']         = 'handi3';
    $config['db_site']['username']         = 'root';
    $config['db_site']['password']         = 'root';

    $config['mail']['debug']               = 'fkeloks@gmail.com';
    $config['mail']['contact']             = 'contact@handi3.fr';
    $config['mail']['admin']               = 'fkeloks@gmail.com';